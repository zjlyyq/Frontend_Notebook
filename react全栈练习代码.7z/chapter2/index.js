const hello = require('./hello')

alert(hello)